<?php 

session_start();
?>



<!DOCTYPE html>
<html lang="en" dir="rtl">

<head>
  <link rel="stylesheet" href="loading.css">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="Image Slider on Website/style.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
  <link rel="stylesheet" href="mobile.css">

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>myITLand</title>
</head>

<body>
  <div class="container">
    <!-- صفحه لودینگ -->
    <div id="loading">
      <div id="loading-text"><div class="ring">ITLand
        <span id="span1" ></span>
      </div></div>
    </div>
    <!-- محتوای صفحه اصلی -->
    <div class="gradient">
      
    </div>
    
    <header>
      <div class="partOfHeader partOfHeader1">
        <img class="logo" src="tasavir/4695738.webp" alt="">
      </div>
      <div class="partOfHeader partOfHeader2">
        <!-- About Us Dropdown -->
        <div class="headerButton headerButton1" onclick="toggleDropdown('aboutDropdown')">درباره ما <svg
            xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
            style="fill: #1B4332; background-color: white; border-radius: 50%;">
            <path d="M16.293 9.293 12 13.586 7.707 9.293l-1.414 1.414L12 16.414l5.707-5.707z"></path>
          </svg> </div>
        <div id="aboutDropdown" class="dropdownContent">
          <a href="/overview" class="dropdownItem">Overview</a>
          <a href="/team" class="dropdownItem">Team</a>
          <a href="/careers" class="dropdownItem">Careers</a>
        </div>
        
        <!-- Support Dropdown -->
        <div class="headerButton headerButton2">پشتیبانی </div>
        
        
        <!-- Home Dropdown -->
        <div class="headerButton headerButton3" onclick="toggleDropdown('homeDropdown')">خانه <svg
          xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
          style="fill: #1B4332;background-color: white; border-radius: 50%;">
          <path d="M16.293 9.293 12 13.586 7.707 9.293l-1.414 1.414L12 16.414l5.707-5.707z"></path>
        </svg></div>
        <div id="homeDropdown" class="dropdownContent dropdownContent1">
          <a href="/main" class="dropdownItem dropdownItem1"><svg class="iconA" xmlns="http://www.w3.org/2000/svg" width="24"
              height="24" viewBox="0 0 24 24" style="fill: var(--zed);">
              <path d="M2 7v1l11 4 9-4V7L11 4z"></path>
              <path
              d="M4 11v4.267c0 1.621 4.001 3.893 9 3.734 4-.126 6.586-1.972 7-3.467.024-.089.037-.178.037-.268V11L13 14l-5-1.667v3.213l-1-.364V12l-3-1z">
            </path>
          </svg>دوره ها</a>
          <a href="/news" class="dropdownItem dropdownItem2"><svg xmlns="http://www.w3.org/2000/svg" width="24"
            height="24" viewBox="0 0 24 20" style="fill: var(--zed);">
            <path
                d="M10 3H4a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1zM9 9H5V5h4v4zm11-6h-6a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1zm-1 6h-4V5h4v4zm-9 4H4a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-6a1 1 0 0 0-1-1zm-1 6H5v-4h4v4zm8-6c-2.206 0-4 1.794-4 4s1.794 4 4 4 4-1.794 4-4-1.794-4-4-4zm0 6c-1.103 0-2-.897-2-2s.897-2 2-2 2 .897 2 2-.897 2-2 2z">
              </path>
            </svg>دسته بندی ها</a>
            <a href="#category" class="dropdownItem dropdownItem3"><svg xmlns="http://www.w3.org/2000/svg" width="24"
              height="24" viewBox="0 0 24 24" style="fill: var(--zed);">
              <path
                d="M19.875 3H4.125C2.953 3 2 3.897 2 5v14c0 1.103.953 2 2.125 2h15.75C21.047 21 22 20.103 22 19V5c0-1.103-.953-2-2.125-2zm0 16H4.125c-.057 0-.096-.016-.113-.016-.007 0-.011.002-.012.008L3.988 5.046c.007-.01.052-.046.137-.046h15.75c.079.001.122.028.125.008l.012 13.946c-.007.01-.052.046-.137.046z">
              </path>
              <path d="M6 7h6v6H6zm7 8H6v2h12v-2h-4zm1-4h4v2h-4zm0-4h4v2h-4z"></path>
            </svg>اخبار</a>
          <a href="/main" class="dropdownItem dropdownItem4"><svg xmlns="http://www.w3.org/2000/svg" width="24"
              height="24" viewBox="0 0 24 24" style="fill: var(--zed);">
              <path
              d="M19 3H5c-1.103 0-2 .897-2 2v14c0 1.103.897 2 2 2h8a.996.996 0 0 0 .707-.293l7-7a.997.997 0 0 0 .196-.293c.014-.03.022-.061.033-.093a.991.991 0 0 0 .051-.259c.002-.021.013-.041.013-.062V5c0-1.103-.897-2-2-2zM5 5h14v7h-6a1 1 0 0 0-1 1v6H5V5zm9 12.586V14h3.586L14 17.586z">
            </path>
          </svg>مقالات رایگان</a>
          <a href="/main" class="dropdownItem dropdownItem5"><svg xmlns="http://www.w3.org/2000/svg" width="24"
              height="24" viewBox="0 0 24 24" style="fill: var(--zed);">
              <path
              d="M20 13.01h-7V10h1c1.103 0 2-.897 2-2V4c0-1.103-.897-2-2-2h-4c-1.103 0-2 .897-2 2v4c0 1.103.897 2 2 2h1v3.01H4V18H3v4h4v-4H6v-2.99h5V18h-1v4h4v-4h-1v-2.99h5V18h-1v4h4v-4h-1v-4.99zM10 8V4h4l.002 4H10z">
            </path>
          </svg>رود مپ</a>
          <div class="dropdownC">
            <h2>پیشنهاد آیتی لند :</h2>
            <p>مقاله جاوا اسکریپت و مقاله پی اچ پی</p>
          </div>
        </div>
        <div class="headerButton headerButton4">
        <?php if (isset($_SESSION['user_email'])) { echo '<a class="linkTwo" href="logout.php">خروج از حساب </a>'; } 
        
        
        else {  
          
          
          echo '<a class="linkOne" href="login/login.php">ورود</a>'; 
          echo '<a class="linkTwo" href="login/register.php">ثبت‌نام</a>'; 
        } 
        ?>

        </div>
      </div>
      <div class="partOfHeader partOfHeader3">
        <div class="headerTitle">
          <h4>itland</h4>
        </div>
        
        
      </div>
      <div class="partOfHeader partOfHeader4">
        <button id="theme-switch">
          <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px">
            <path
            d="M480-120q-150 0-255-105T120-480q0-150 105-255t255-105q14 0 27.5 1t26.5 3q-41 29-65.5 75.5T444-660q0 90 63 153t153 63q55 0 101-24.5t75-65.5q2 13 3 26.5t1 27.5q0 150-105 255T480-120Z" />
          </svg>
          <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px">
            <path
            d="M480-280q-83 0-141.5-58.5T280-480q0-83 58.5-141.5T480-680q83 0 141.5 58.5T680-480q0 83-58.5 141.5T480-280ZM200-440H40v-80h160v80Zm720 0H760v-80h160v80ZM440-760v-160h80v160h-80Zm0 720v-160h80v160h-80ZM256-650l-101-97 57-59 96 100-52 56Zm492 496-97-101 53-55 101 97-57 59Zm-98-550 97-101 59 57-100 96-56-52ZM154-212l101-97 55 53-97 101-59-57Z" />
          </svg>
        </button>
      </div>
      <div class="hamburger-menu">
        <div class="hamburger-icon"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24"
          style="fill: var(--base-color); ">
            <path d="M4 6h16v2H4zm0 5h16v2H4zm0 5h16v2H4z"></path>
          </svg></div>
          <div class="menu" id="menu">
            <div class="headOfMenu">
            <div class="close-icon" id="close-icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                viewBox="0 0 24 24" style="fill: var(--base-color);">
                <path
                  d="m16.192 6.344-4.243 4.242-4.242-4.242-1.414 1.414L10.535 12l-4.242 4.242 1.414 1.414 4.242-4.242 4.243 4.242 1.414-1.414L13.364 12l4.242-4.242z">
                </path>
              </svg></div> <!-- آیکون ضربدر -->
            <button id="theme-switch2">
              <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px">
                <path
                d="M480-120q-150 0-255-105T120-480q0-150 105-255t255-105q14 0 27.5 1t26.5 3q-41 29-65.5 75.5T444-660q0 90 63 153t153 63q55 0 101-24.5t75-65.5q2 13 3 26.5t1 27.5q0 150-105 255T480-120Z" />
              </svg>
              <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px">
                <path
                d="M480-280q-83 0-141.5-58.5T280-480q0-83 58.5-141.5T480-680q83 0 141.5 58.5T680-480q0 83-58.5 141.5T480-280ZM200-440H40v-80h160v80Zm720 0H760v-80h160v80ZM440-760v-160h80v160h-80Zm0 720v-160h80v160h-80ZM256-650l-101-97 57-59 96 100-52 56Zm492 496-97-101 53-55 101 97-57 59Zm-98-550 97-101 59 57-100 96-56-52ZM154-212l101-97 55 53-97 101-59-57Z" />
              </svg>
            </button>
            <div class="headerButton headerButton4">
              <a class="linkOne" href="login/login.php">ورود</a>
              <a class="linkTwo" href="login/rgister.php">ثبت نام</a>
            </div>
          </div>
          <div class="menu-item">
            <button class="menu-btn">
              خانه
              <span class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                style="fill: var(--text-color);">
                <path d="M16.293 9.293 12 13.586 7.707 9.293l-1.414 1.414L12 16.414l5.707-5.707z"></path>
              </svg></span>
              
            </button>
            <div class="dropdown-content">
              <a href="#">لینک 1</a>
              <a href="#">لینک 2</a>
              <a href="#">لینک 3</a>
            </div>
          </div>
          <!-- بقیه منو ها... -->
          <div class="menu-item">
            <button class="menu-btn">
              درباره ما
              <span class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                style="fill: var(--text-color);">
                <path d="M16.293 9.293 12 13.586 7.707 9.293l-1.414 1.414L12 16.414l5.707-5.707z"></path>
              </svg></span>
            </button>
            <div class="dropdown-content">
              <a href="#">لینک 1</a>
              <a href="#">لینک 2</a>
              <a href="#">لینک 3</a>
            </div>
          </div>

          <div class="menu-item">
            <button class="menu-btn">
              پشتیبانی
              <span class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                  style="fill: var(--text-color)">
                  <path d="M16.293 9.293 12 13.586 7.707 9.293l-1.414 1.414L12 16.414l5.707-5.707z"></path>
                </svg></span>
            </button>
            <div class="dropdown-content">
              <a href="#">لینک 1</a>
              <a href="#">لینک 2</a>
              <a href="#">لینک 3</a>
            </div>
          </div>
        </header>
        <div class="space">
          
        </div>
  </div>
  <div id="base" class="baseOf">
    <img class="moon2" src="svgHa/b8420a7ec558f6cd2e796a3fabffa775.png" alt="">
    <img class="moon" src="svgHa/—Pngtree—hazy and beautiful halo moon_5336588.png" alt="">
    <div class="bigPicture">
      <div class="bigText">
        <h2>سایت مقاله ای آیتی لند</h2>
        <p>مقالات رایگان و بروز برنامه نویسی در دنیا با آیتی لند</p>
        <a href="#slider" class="bigText1">اسکرول کنید
          <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="3 0 17 17"
          style="fill: var(--text-color);  border-radius: 50%;">
          <path d="M16.293 9.293 12 13.586 7.707 9.293l-1.414 1.414L12 16.414l5.707-5.707z"></path>
        </svg>
      </a>
    </div>
    <img class="img1" src="svgHa/ITLand.png" alt="">
    <img class="img2" src="svgHa/ITLand2.png" alt="">
  </div>
  
  <div class="primarySection">
    
    <div id="slider" class="slider block">
      <section class="main swiper mySwiper">
        <div class="wrapper swiper-wrapper">
          <div class="slide swiper-slide">
            <img src="Image Slider on Website/images/banner.jpg" alt="" class="image" />
            <img class="logoSlider"
            src="tasavir/kisspng-logo-web-development-business-company-programmer-5ac6bd6d2129e5.6658857615229740611359.png"
            alt="">
            <div class="image-data">
              <span class="text">جاوا اسکریپت</span>
              <h2 class="sliderText">
                جزوه کامل جاوا اسکریپت
              </h2>
              <a href="#" class="button">ادامه</a>
            </div>
            </div>
            <div class="slide swiper-slide">
              <img src="Image Slider on Website/images/img1.jpg" alt="" class="image" />
              <div class="image-data">
                <span class="text">مقالاتی درباره زندگی بزگان</span>
                <h2 class="sliderText">
                  از زندگینامه ها لذت ببرید <br />
                  مقالات درسی ایتی لند
                </h2>
                <a href="#" class="button">ادامه</a>
              </div>
            </div>
            <div class="slide swiper-slide">
              <img src="Image Slider on Website/images/img2.jpg" alt="" class="image" />
              <div class="image-data">
                <span class="text">مقالاتی درباره زندگی بزگان</span>
                <h2 class="sliderText">
                  از زندگینامه ها لذت ببرید <br />
                  مقالات درسی ایتی لند
                </h2>
                <a href="#" class="button">ادامه</a>
              </div>
            </div>
          </div>

          <div class="swiper-button-next nav-btn"></div>
          <div class="swiper-button-prev nav-btn"></div>
          <div class="swiper-pagination"></div>
        </section>
        
        <!-- Swiper JS -->
        <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
        
        <!-- Initialize Swiper -->
        <script>
          var swiper = new Swiper(".mySwiper", {
            slidesPerView: 1,
            loop: true,
            pagination: {
              el: ".swiper-pagination",
              clickable: true,
            },
            navigation: {
              nextEl: ".swiper-button-next",
              prevEl: ".swiper-button-prev",
            },
          });
        </script>
      </div>
      
      <div class="slider block">
        <section class="main swiper mySwiper">
          <div class="wrapper swiper-wrapper">
            <div class="slide swiper-slide">
              <img src="Image Slider on Website/images/img3.jpg" alt="" class="image" />
              <div class="image-data">
                <span class="text">مقالاتی درباره زندگی بزگان</span>
                <h2 class="sliderText">
                  از زندگینامه ها لذت ببرید <br />
                  مقالات درسی ایتی لند
                </h2>
                <a href="#" class="button">ادامه</a>
              </div>
            </div>
            <div class="slide swiper-slide">
              <img src="Image Slider on Website/images/img1.jpg" alt="" class="image" />
              <div class="image-data">
                <span class="text">مقالاتی درباره زندگی بزگان</span>
                <h2 class="sliderText">
                  از زندگینامه ها لذت ببرید <br />
                  مقالات درسی ایتی لند
                </h2>
                <a href="#" class="button">ادامه</a>
              </div>
            </div>
            <div class="slide swiper-slide">
              <img src="Image Slider on Website/images/img2.jpg" alt="" class="image" />
              <div class="image-data">
                <span class="text">مقالاتی درباره زندگی بزگان</span>
                <h2 class="sliderText">
                  از زندگینامه ها لذت ببرید <br />
                  مقالات درسی ایتی لند
                </h2>
                <a href="#" class="button">ادامه</a>
              </div>
            </div>
          </div>

          <div class="swiper-button-next nav-btn"></div>
          <div class="swiper-button-prev nav-btn"></div>
          <div class="swiper-pagination"></div>
        </section>
        
        <!-- Swiper JS -->
        <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
        
        <!-- Initialize Swiper -->
        <script>
          var swiper = new Swiper(".mySwiper", {
            slidesPerView: 1,
            loop: true,
            pagination: {
              el: ".swiper-pagination",
              clickable: true,
            },
            navigation: {
              nextEl: ".swiper-button-next",
              prevEl: ".swiper-button-prev",
            },
          });
        </script>
      </div>
    </div>
    
    <div id="category" class="addMaqaleh block">
      <h2 class="addText">افزودن مقاله</h2>
      <div class="addContents">
        <div class="addContent rules">
          <p id="Mcontent">قوانین
            <svg class="icon" xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="3 0 17 17"
            style="fill: var(--text-color);  border-radius: 50%;">
            <path d="M16.293 9.293 12 13.586 7.707 9.293l-1.414 1.414L12 16.414l5.707-5.707z"></path>
          </svg>
        </p>
        <span class="Mtexts ">مقالات حتما باید از منابع موصق باشد<br> مقالات باید اخلاقی باشد</span>
      </div>
      <div class="addContent learn">
        <p id="Lcontent">آموزش
          <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="3 0 17 17"
          style="fill: var(--text-color);  border-radius: 50%;">
          <path d="M16.293 9.293 12 13.586 7.707 9.293l-1.414 1.414L12 16.414l5.707-5.707z"></path>
        </svg>
      </p>
      <span class="Ltexts ">مقالات حتما باید از منابع موصق باشد<br> مقالات باید اخلاقی باشد</span>
    </div>
  </div>
</div>
</div>
</footer>
</div>

<footer>
  <div class="footerSection footerSection1">
    <div class="footerImage">
      <img src="tasavir/highlight.jpg" alt="">
    </div>
    <div class="footerImage">
      <img src="tasavir/4695738.webp" alt="">
      
    </div>
  </div>
  <div class="footerSection2">

    <ul>
      <li><a href="google.com"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
              style="fill: rgba(255, 255, 255, 1);">
              <path
              d="M19.633 7.997c.013.175.013.349.013.523 0 5.325-4.053 11.461-11.46 11.461-2.282 0-4.402-.661-6.186-1.809.324.037.636.05.973.05a8.07 8.07 0 0 0 5.001-1.721 4.036 4.036 0 0 1-3.767-2.793c.249.037.499.062.761.062.361 0 .724-.05 1.061-.137a4.027 4.027 0 0 1-3.23-3.953v-.05c.537.299 1.16.486 1.82.511a4.022 4.022 0 0 1-1.796-3.354c0-.748.199-1.434.548-2.032a11.457 11.457 0 0 0 8.306 4.215c-.062-.3-.1-.611-.1-.923a4.026 4.026 0 0 1 4.028-4.028c1.16 0 2.207.486 2.943 1.272a7.957 7.957 0 0 0 2.556-.973 4.02 4.02 0 0 1-1.771 2.22 8.073 8.073 0 0 0 2.319-.624 8.645 8.645 0 0 1-2.019 2.083z">
            </path>
            </svg></a></li>
            <li><a href="google.com"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
              style="fill: rgba(255, 255, 255, 1);">
              <path
              d="m18.73 5.41-1.28 1L12 10.46 6.55 6.37l-1.28-1A2 2 0 0 0 2 7.05v11.59A1.36 1.36 0 0 0 3.36 20h3.19v-7.72L12 16.37l5.45-4.09V20h3.19A1.36 1.36 0 0 0 22 18.64V7.05a2 2 0 0 0-3.27-1.64z">
            </path>
          </svg></a></li>
          <li><a href="google.com"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
            style="fill: rgba(255, 255, 255, 1);">
            <path
            d="M20.947 8.305a6.53 6.53 0 0 0-.419-2.216 4.61 4.61 0 0 0-2.633-2.633 6.606 6.606 0 0 0-2.186-.42c-.962-.043-1.267-.055-3.709-.055s-2.755 0-3.71.055a6.606 6.606 0 0 0-2.185.42 4.607 4.607 0 0 0-2.633 2.633 6.554 6.554 0 0 0-.419 2.185c-.043.963-.056 1.268-.056 3.71s0 2.754.056 3.71c.015.748.156 1.486.419 2.187a4.61 4.61 0 0 0 2.634 2.632 6.584 6.584 0 0 0 2.185.45c.963.043 1.268.056 3.71.056s2.755 0 3.71-.056a6.59 6.59 0 0 0 2.186-.419 4.615 4.615 0 0 0 2.633-2.633c.263-.7.404-1.438.419-2.187.043-.962.056-1.267.056-3.71-.002-2.442-.002-2.752-.058-3.709zm-8.953 8.297c-2.554 0-4.623-2.069-4.623-4.623s2.069-4.623 4.623-4.623a4.623 4.623 0 0 1 0 9.246zm4.807-8.339a1.077 1.077 0 0 1-1.078-1.078 1.077 1.077 0 1 1 2.155 0c0 .596-.482 1.078-1.077 1.078z">
          </path>
          <circle cx="11.994" cy="11.979" r="3.003"></circle>
        </svg></a></li>
        <li><a href="google.com"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
          style="fill: rgba(255, 255, 255, 1);">
              <path fill-rule="evenodd" clip-rule="evenodd"
              d="M12.026 2c-5.509 0-9.974 4.465-9.974 9.974 0 4.406 2.857 8.145 6.821 9.465.499.09.679-.217.679-.481 0-.237-.008-.865-.011-1.696-2.775.602-3.361-1.338-3.361-1.338-.452-1.152-1.107-1.459-1.107-1.459-.905-.619.069-.605.069-.605 1.002.07 1.527 1.028 1.527 1.028.89 1.524 2.336 1.084 2.902.829.091-.645.351-1.085.635-1.334-2.214-.251-4.542-1.107-4.542-4.93 0-1.087.389-1.979 1.024-2.675-.101-.253-.446-1.268.099-2.64 0 0 .837-.269 2.742 1.021a9.582 9.582 0 0 1 2.496-.336 9.554 9.554 0 0 1 2.496.336c1.906-1.291 2.742-1.021 2.742-1.021.545 1.372.203 2.387.099 2.64.64.696 1.024 1.587 1.024 2.675 0 3.833-2.33 4.675-4.552 4.922.355.308.675.916.675 1.846 0 1.334-.012 2.41-.012 2.737 0 .267.178.577.687.479C19.146 20.115 22 16.379 22 11.974 22 6.465 17.535 2 12.026 2z">
            </path>
          </svg></a></li>
          <li>
            <p>👋</p>
          </li>
        </ul>
        
      </div>
      <div class="footerSection"></div>
      <div class="footerSection"></div>
    </footer>
    
    
    
  </div>
  
  
  <script type="text/javascript" src="darkmode.js"></script>
  <script src="script.js"></script>
 
</body>

</html>